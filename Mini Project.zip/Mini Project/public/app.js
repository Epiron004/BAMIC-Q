// Socket.io connection
const socket = io();

// DOM Elements
const queueList = document.getElementById('queueList');
const bedStatus = document.getElementById('bedStatus');
const addToQueueBtn = document.getElementById('addToQueue');
const updateBedStatusBtn = document.getElementById('updateBedStatus');
const admissionForm = document.getElementById('admissionForm');

// Sample data for demonstration
let queue = [];
let beds = [
    { id: 1, status: 'available', department: 'cardiology' },
    { id: 2, status: 'occupied', department: 'orthopedics' },
    { id: 3, status: 'available', department: 'pediatrics' }
];

// Update queue display
function updateQueueDisplay() {
    queueList.innerHTML = '';
    queue.forEach((patient, index) => {
        const queueItem = document.createElement('div');
        queueItem.className = 'queue-item';
        queueItem.innerHTML = `
            <span>${index + 1}. ${patient.name}</span>
            <span>${patient.department}</span>
        `;
        queueList.appendChild(queueItem);
    });
}

// Update bed status display
function updateBedStatusDisplay() {
    bedStatus.innerHTML = '';
    beds.forEach(bed => {
        const bedItem = document.createElement('div');
        bedItem.className = 'bed-item';
        bedItem.innerHTML = `
            <span>Bed ${bed.id} - ${bed.department}</span>
            <span class="status-${bed.status}">${bed.status}</span>
        `;
        bedStatus.appendChild(bedItem);
    });
}

// Add patient to queue
addToQueueBtn.addEventListener('click', () => {
    const patientName = prompt('Enter patient name:');
    const department = prompt('Enter department:');
    
    if (patientName && department) {
        const patient = {
            name: patientName,
            department: department,
            timestamp: new Date()
        };
        
        queue.push(patient);
        socket.emit('join-queue', patient);
        updateQueueDisplay();
    }
});

// Update bed status
updateBedStatusBtn.addEventListener('click', () => {
    const bedId = prompt('Enter bed ID:');
    const newStatus = prompt('Enter new status (available/occupied):');
    
    if (bedId && newStatus) {
        const bed = beds.find(b => b.id === parseInt(bedId));
        if (bed) {
            bed.status = newStatus;
            socket.emit('bed-status', { id: bedId, status: newStatus });
            updateBedStatusDisplay();
        }
    }
});

// Handle patient admission
admissionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const patientName = document.getElementById('patientName').value;
    const patientId = document.getElementById('patientId').value;
    const department = document.getElementById('department').value;
    
    // Here you would typically send this data to the server
    console.log('Admitting patient:', { patientName, patientId, department });
    
    // Clear form
    admissionForm.reset();
});

// Socket.io event listeners
socket.on('queue-update', (data) => {
    queue.push(data);
    updateQueueDisplay();
});

socket.on('bed-update', (data) => {
    const bed = beds.find(b => b.id === data.id);
    if (bed) {
        bed.status = data.status;
        updateBedStatusDisplay();
    }
});

// Initialize displays
updateQueueDisplay();
updateBedStatusDisplay(); 