// Socket.io connection
const socket = io();

// DOM Elements
const totalPatientsElement = document.getElementById('totalPatients');
const activeAdmissionsElement = document.getElementById('activeAdmissions');
const availableBedsElement = document.getElementById('availableBeds');
const opdQueueElement = document.getElementById('opdQueue');
const logList = document.getElementById('logList');
const logType = document.getElementById('logType');
const logDate = document.getElementById('logDate');

// Sample data for demonstration
let systemLogs = [];
let totalPatients = 0;
let activeAdmissions = 0;
let availableBeds = 0;
let opdQueue = 0;

// Initialize charts
const admissionsChart = new Chart(document.getElementById('admissionsChart'), {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
            label: 'Daily Admissions',
            data: [12, 19, 15, 17, 14, 8, 10],
            borderColor: '#3498db',
            tension: 0.1
        }]
    }
});

const bedOccupancyChart = new Chart(document.getElementById('bedOccupancyChart'), {
    type: 'doughnut',
    data: {
        labels: ['Available', 'Occupied', 'Maintenance'],
        datasets: [{
            data: [30, 45, 5],
            backgroundColor: ['#27ae60', '#e74c3c', '#f39c12']
        }]
    }
});

const departmentChart = new Chart(document.getElementById('departmentChart'), {
    type: 'bar',
    data: {
        labels: ['Cardiology', 'Orthopedics', 'Pediatrics', 'General'],
        datasets: [{
            label: 'Patients by Department',
            data: [25, 30, 20, 25],
            backgroundColor: '#3498db'
        }]
    }
});

// Update system statistics
function updateStats() {
    totalPatientsElement.textContent = totalPatients;
    activeAdmissionsElement.textContent = activeAdmissions;
    availableBedsElement.textContent = availableBeds;
    opdQueueElement.textContent = opdQueue;
}

// Update system logs
function updateLogs() {
    logList.innerHTML = '';
    const selectedType = logType.value;
    const selectedDate = logDate.value;
    
    const filteredLogs = systemLogs.filter(log => {
        const matchesType = selectedType === 'all' || log.type === selectedType;
        const matchesDate = !selectedDate || new Date(log.timestamp).toDateString() === new Date(selectedDate).toDateString();
        return matchesType && matchesDate;
    });
    
    filteredLogs.forEach(log => {
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';
        logEntry.innerHTML = `
            <span class="log-timestamp">${new Date(log.timestamp).toLocaleString()}</span>
            <span class="log-type ${log.type}">${log.type}</span>
            <span class="log-message">${log.message}</span>
        `;
        logList.appendChild(logEntry);
    });
}

// System control functions
function clearAllQueues() {
    if (confirm('Are you sure you want to clear all queues?')) {
        socket.emit('clear-all-queues');
        addLog('queue', 'All queues cleared by admin');
    }
}

function exportQueueData() {
    // In a real application, this would export data to a file
    alert('Queue data exported successfully!');
    addLog('system', 'Queue data exported');
}

function addNewBed() {
    const ward = prompt('Enter ward for new bed:');
    if (ward) {
        socket.emit('add-bed', { ward });
        addLog('bed', `New bed added to ${ward} ward`);
    }
}

function updateBedStatuses() {
    // In a real application, this would open a modal for bulk updates
    alert('Bed status update interface opened');
    addLog('system', 'Bulk bed status update initiated');
}

function backupSystem() {
    // In a real application, this would trigger a backup
    alert('System backup initiated');
    addLog('system', 'System backup started');
}

function restoreSystem() {
    // In a real application, this would restore from backup
    if (confirm('Are you sure you want to restore the system?')) {
        alert('System restore initiated');
        addLog('system', 'System restore started');
    }
}

// Add log entry
function addLog(type, message) {
    const log = {
        timestamp: new Date(),
        type: type,
        message: message
    };
    systemLogs.push(log);
    updateLogs();
}

// Event listeners
logType.addEventListener('change', updateLogs);
logDate.addEventListener('change', updateLogs);

// Socket.io event listeners
socket.on('queue-update', (data) => {
    opdQueue = data.length;
    updateStats();
    addLog('queue', `Queue updated: ${data.length} patients in queue`);
});

socket.on('bed-update', (data) => {
    availableBeds = data.available;
    updateStats();
    addLog('bed', `Bed status updated: ${data.status}`);
});

socket.on('new-admission', (data) => {
    totalPatients++;
    activeAdmissions++;
    updateStats();
    addLog('admission', `New patient admitted: ${data.firstName} ${data.lastName}`);
});

// Initialize
updateStats();
updateLogs(); 