// Socket.io connection
const socket = io();

// DOM Elements
const patientAdmissionForm = document.getElementById('patientAdmissionForm');
const todayAdmissionsElement = document.getElementById('todayAdmissions');
const currentInpatientsElement = document.getElementById('currentInpatients');
const availableBedsElement = document.getElementById('availableBeds');

// Sample data for demonstration
let admissions = [];
let inpatients = 0;
let availableBeds = 0;

// Handle form submission
patientAdmissionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const patientData = {
        id: Date.now(),
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        dob: document.getElementById('dob').value,
        gender: document.getElementById('gender').value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value,
        department: document.getElementById('department').value,
        admissionType: document.getElementById('admissionType').value,
        medicalHistory: document.getElementById('medicalHistory').value,
        allergies: document.getElementById('allergies').value,
        insuranceProvider: document.getElementById('insuranceProvider').value,
        policyNumber: document.getElementById('policyNumber').value,
        admissionDate: new Date(),
        status: 'admitted'
    };
    
    // Add to admissions list
    admissions.push(patientData);
    inpatients++;
    availableBeds--;
    
    // Emit socket event
    socket.emit('new-admission', patientData);
    
    // Update statistics
    updateStats();
    
    // Show success message
    alert('Patient admitted successfully!');
    
    // Reset form
    patientAdmissionForm.reset();
});

// Update statistics
function updateStats() {
    const today = new Date().toDateString();
    const todayAdmissions = admissions.filter(admission => 
        new Date(admission.admissionDate).toDateString() === today
    ).length;
    
    todayAdmissionsElement.textContent = todayAdmissions;
    currentInpatientsElement.textContent = inpatients;
    availableBedsElement.textContent = availableBeds;
}

// Socket.io event listeners
socket.on('new-admission', (data) => {
    admissions.push(data);
    inpatients++;
    availableBeds--;
    updateStats();
});

socket.on('bed-update', (data) => {
    if (data.status === 'available') {
        availableBeds++;
    } else if (data.status === 'occupied') {
        availableBeds--;
    }
    updateStats();
});

// Initialize
updateStats(); 