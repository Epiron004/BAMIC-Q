// Socket.io connection
const socket = io();

// DOM Elements
const updateBedForm = document.getElementById('updateBedForm');
const bedGrid = document.getElementById('bedGrid');
const wardFilter = document.getElementById('wardFilter');
const totalBedsElement = document.getElementById('totalBeds');
const availableBedsElement = document.getElementById('availableBeds');
const occupiedBedsElement = document.getElementById('occupiedBeds');

// Bed data
let beds = [
    { id: 1, ward: 'general', status: 'available', patient: null },
    { id: 2, ward: 'general', status: 'occupied', patient: 'John Doe' },
    { id: 3, ward: 'icu', status: 'available', patient: null },
    { id: 4, ward: 'icu', status: 'occupied', patient: 'Jane Smith' },
    { id: 5, ward: 'pediatric', status: 'available', patient: null },
    { id: 6, ward: 'pediatric', status: 'maintenance', patient: null },
    { id: 7, ward: 'maternity', status: 'available', patient: null },
    { id: 8, ward: 'maternity', status: 'occupied', patient: 'Mary Johnson' }
];

// Update bed status
updateBedForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const ward = document.getElementById('ward').value;
    const status = document.getElementById('bedStatus').value;
    const patientName = document.getElementById('patientName').value;
    
    const bed = {
        id: Date.now(),
        ward: ward,
        status: status,
        patient: status === 'occupied' ? patientName : null
    };
    
    beds.push(bed);
    socket.emit('update-bed', bed);
    updateBedDisplay();
    updateStats();
    
    // Reset form
    updateBedForm.reset();
});

// Filter beds by ward
wardFilter.addEventListener('change', () => {
    updateBedDisplay();
});

// Update bed display
function updateBedDisplay() {
    bedGrid.innerHTML = '';
    const selectedWard = wardFilter.value;
    
    const filteredBeds = selectedWard === 'all' 
        ? beds 
        : beds.filter(bed => bed.ward === selectedWard);
    
    filteredBeds.forEach(bed => {
        const bedItem = document.createElement('div');
        bedItem.className = `bed-item status-${bed.status}`;
        bedItem.innerHTML = `
            <div class="bed-info">
                <span class="bed-id">Bed ${bed.id}</span>
                <span class="ward">${bed.ward}</span>
            </div>
            <div class="bed-status">
                <span class="status">${bed.status}</span>
                ${bed.patient ? `<span class="patient">${bed.patient}</span>` : ''}
            </div>
            <div class="bed-actions">
                <button class="btn btn-small" onclick="updateBedStatus(${bed.id})">Update</button>
                <button class="btn btn-small btn-danger" onclick="removeBed(${bed.id})">Remove</button>
            </div>
        `;
        bedGrid.appendChild(bedItem);
    });
}

// Update statistics
function updateStats() {
    totalBedsElement.textContent = beds.length;
    availableBedsElement.textContent = beds.filter(bed => bed.status === 'available').length;
    occupiedBedsElement.textContent = beds.filter(bed => bed.status === 'occupied').length;
}

// Update bed status
function updateBedStatus(bedId) {
    const bed = beds.find(b => b.id === bedId);
    if (bed) {
        const newStatus = prompt('Enter new status (available/occupied/maintenance):');
        if (newStatus) {
            bed.status = newStatus;
            if (newStatus === 'occupied') {
                const patientName = prompt('Enter patient name:');
                bed.patient = patientName;
            } else {
                bed.patient = null;
            }
            socket.emit('update-bed', bed);
            updateBedDisplay();
            updateStats();
        }
    }
}

// Remove bed
function removeBed(bedId) {
    if (confirm('Are you sure you want to remove this bed?')) {
        beds = beds.filter(b => b.id !== bedId);
        socket.emit('remove-bed', bedId);
        updateBedDisplay();
        updateStats();
    }
}

// Socket.io event listeners
socket.on('update-bed', (data) => {
    const index = beds.findIndex(b => b.id === data.id);
    if (index !== -1) {
        beds[index] = data;
    } else {
        beds.push(data);
    }
    updateBedDisplay();
    updateStats();
});

socket.on('remove-bed', (bedId) => {
    beds = beds.filter(b => b.id !== bedId);
    updateBedDisplay();
    updateStats();
});

// Initialize
updateBedDisplay();
updateStats(); 