// Socket.io connection
const socket = io();

// DOM Elements
const addPatientForm = document.getElementById('addPatientForm');
const queueList = document.getElementById('queueList');
const departmentFilter = document.getElementById('departmentFilter');
const clearQueueBtn = document.getElementById('clearQueue');
const totalQueueElement = document.getElementById('totalQueue');
const avgWaitTimeElement = document.getElementById('avgWaitTime');
const nextAvailableElement = document.getElementById('nextAvailable');

// Queue data
let queue = [];
const averageConsultationTime = 15; // minutes

// Add patient to queue
addPatientForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const patientName = document.getElementById('patientName').value;
    const department = document.getElementById('department').value;
    const priority = document.getElementById('priority').value;
    
    const patient = {
        id: Date.now(),
        name: patientName,
        department: department,
        priority: priority,
        timestamp: new Date(),
        status: 'waiting'
    };
    
    queue.push(patient);
    socket.emit('join-queue', patient);
    updateQueueDisplay();
    updateStats();
    
    // Reset form
    addPatientForm.reset();
});

// Filter queue by department
departmentFilter.addEventListener('change', () => {
    updateQueueDisplay();
});

// Clear queue
clearQueueBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear the queue?')) {
        queue = [];
        socket.emit('clear-queue');
        updateQueueDisplay();
        updateStats();
    }
});

// Update queue display
function updateQueueDisplay() {
    queueList.innerHTML = '';
    const selectedDepartment = departmentFilter.value;
    
    const filteredQueue = selectedDepartment === 'all' 
        ? queue 
        : queue.filter(patient => patient.department === selectedDepartment);
    
    filteredQueue.forEach((patient, index) => {
        const queueItem = document.createElement('div');
        queueItem.className = `queue-item priority-${patient.priority}`;
        queueItem.innerHTML = `
            <div class="queue-item-info">
                <span class="queue-number">${index + 1}</span>
                <span class="patient-name">${patient.name}</span>
                <span class="department">${patient.department}</span>
            </div>
            <div class="queue-item-actions">
                <span class="priority ${patient.priority}">${patient.priority}</span>
                <button class="btn btn-small" onclick="callPatient(${patient.id})">Call</button>
                <button class="btn btn-small btn-danger" onclick="removePatient(${patient.id})">Remove</button>
            </div>
        `;
        queueList.appendChild(queueItem);
    });
}

// Update statistics
function updateStats() {
    totalQueueElement.textContent = queue.length;
    
    if (queue.length > 0) {
        const avgWaitTime = (queue.length * averageConsultationTime) / 2;
        avgWaitTimeElement.textContent = `${Math.round(avgWaitTime)} min`;
        
        const nextPatient = queue[0];
        nextAvailableElement.textContent = nextPatient.name;
    } else {
        avgWaitTimeElement.textContent = '0 min';
        nextAvailableElement.textContent = '-';
    }
}

// Call patient
function callPatient(patientId) {
    const patient = queue.find(p => p.id === patientId);
    if (patient) {
        patient.status = 'called';
        socket.emit('call-patient', patient);
        updateQueueDisplay();
    }
}

// Remove patient from queue
function removePatient(patientId) {
    queue = queue.filter(p => p.id !== patientId);
    socket.emit('remove-patient', patientId);
    updateQueueDisplay();
    updateStats();
}

// Socket.io event listeners
socket.on('queue-update', (data) => {
    queue.push(data);
    updateQueueDisplay();
    updateStats();
});

socket.on('clear-queue', () => {
    queue = [];
    updateQueueDisplay();
    updateStats();
});

socket.on('remove-patient', (patientId) => {
    queue = queue.filter(p => p.id !== patientId);
    updateQueueDisplay();
    updateStats();
});

// Initialize
updateQueueDisplay();
updateStats(); 