const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { auth, authorize } = require('../middleware/auth');

// Register new user
router.post('/register', auth, authorize(['Admin']), adminController.registerUser);

// Login user
router.post('/login', adminController.loginUser);

// Get all users
router.get('/users', auth, authorize(['Admin']), adminController.getAllUsers);

// Get single user
router.get('/users/:id', auth, authorize(['Admin']), adminController.getUser);

// Update user
router.put('/users/:id', auth, authorize(['Admin']), adminController.updateUser);

// Delete user
router.delete('/users/:id', auth, authorize(['Admin']), adminController.deleteUser);

// Change password
router.put('/users/:id/password', auth, adminController.changePassword);

// Get system statistics
router.get('/stats', auth, authorize(['Admin']), adminController.getSystemStats);

module.exports = router; 