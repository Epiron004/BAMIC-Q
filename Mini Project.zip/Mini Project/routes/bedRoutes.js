const express = require('express');
const router = express.Router();
const bedController = require('../controllers/bedController');
const { auth, authorize } = require('../middleware/auth');

// Get all beds
router.get('/', auth, bedController.getAllBeds);

// Get single bed
router.get('/:id', auth, bedController.getBed);

// Create new bed
router.post('/', auth, authorize(['Admin']), bedController.createBed);

// Update bed
router.put('/:id', auth, authorize(['Admin']), bedController.updateBed);

// Delete bed
router.delete('/:id', auth, authorize(['Admin']), bedController.deleteBed);

// Get available beds
router.get('/available', auth, bedController.getAvailableBeds);

// Get beds by ward
router.get('/ward/:ward', auth, bedController.getBedsByWard);

// Update bed status
router.put('/:id/status', auth, authorize(['Admin', 'Nurse']), bedController.updateBedStatus);

module.exports = router; 