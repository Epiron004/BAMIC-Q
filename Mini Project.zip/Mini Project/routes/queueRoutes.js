const express = require('express');
const router = express.Router();
const queueController = require('../controllers/queueController');
const { auth, authorize } = require('../middleware/auth');

// Get all queues
router.get('/', auth, queueController.getAllQueues);

// Get queues by department
router.get('/department/:department', auth, queueController.getQueuesByDepartment);

// Add patient to queue
router.post('/', auth, authorize(['Admin', 'Receptionist']), queueController.addToQueue);

// Update queue status
router.put('/:id/status', auth, authorize(['Admin', 'Doctor']), queueController.updateQueueStatus);

// Remove from queue
router.delete('/:id', auth, authorize(['Admin', 'Receptionist']), queueController.removeFromQueue);

// Get current queue position
router.get('/:id/position', auth, queueController.getQueuePosition);

// Get waiting time estimate
router.get('/:id/waiting-time', auth, queueController.getWaitingTime);

module.exports = router; 