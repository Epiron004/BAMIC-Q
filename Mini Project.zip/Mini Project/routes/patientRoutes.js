const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patientController');
const { auth, authorize } = require('../middleware/auth');

// Get all patients
router.get('/', auth, patientController.getAllPatients);

// Get single patient
router.get('/:id', auth, patientController.getPatient);

// Create new patient
router.post('/', auth, authorize(['Admin', 'Receptionist']), patientController.createPatient);

// Update patient
router.put('/:id', auth, authorize(['Admin', 'Receptionist']), patientController.updatePatient);

// Delete patient
router.delete('/:id', auth, authorize(['Admin']), patientController.deletePatient);

// Admit patient
router.post('/:id/admit', auth, authorize(['Admin', 'Receptionist']), patientController.admitPatient);

// Discharge patient
router.post('/:id/discharge', auth, authorize(['Admin', 'Receptionist']), patientController.dischargePatient);

module.exports = router; 