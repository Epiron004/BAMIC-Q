const Queue = require('../models/Queue');
const Patient = require('../models/Patient');

// Get all queues
exports.getAllQueues = async (req, res) => {
  try {
    const queues = await Queue.find()
      .populate('patient')
      .sort({ queueNumber: 1 });
    res.json(queues);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get queues by department
exports.getQueuesByDepartment = async (req, res) => {
  try {
    const queues = await Queue.find({ department: req.params.department })
      .populate('patient')
      .sort({ priority: -1, queueNumber: 1 });
    res.json(queues);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Add patient to queue
exports.addToQueue = async (req, res) => {
  try {
    const { patientId, department, priority } = req.body;

    // Get the last queue number for the department
    const lastQueue = await Queue.findOne({ department })
      .sort({ queueNumber: -1 });

    const queueNumber = lastQueue ? lastQueue.queueNumber + 1 : 1;

    const queue = new Queue({
      patient: patientId,
      department,
      priority: priority || 'Medium',
      queueNumber
    });

    await queue.save();
    res.status(201).json(queue);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update queue status
exports.updateQueueStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const queue = await Queue.findById(req.params.id);
    
    if (!queue) {
      return res.status(404).json({ message: 'Queue entry not found' });
    }

    queue.status = status;
    
    if (status === 'In Progress') {
      queue.startTime = new Date();
    } else if (status === 'Completed' || status === 'Cancelled') {
      queue.endTime = new Date();
    }

    await queue.save();
    res.json(queue);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Remove from queue
exports.removeFromQueue = async (req, res) => {
  try {
    const queue = await Queue.findById(req.params.id);
    if (!queue) {
      return res.status(404).json({ message: 'Queue entry not found' });
    }

    await queue.remove();
    res.json({ message: 'Removed from queue successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get current queue position
exports.getQueuePosition = async (req, res) => {
  try {
    const queue = await Queue.findById(req.params.id);
    if (!queue) {
      return res.status(404).json({ message: 'Queue entry not found' });
    }

    const position = await Queue.countDocuments({
      department: queue.department,
      status: 'Waiting',
      $or: [
        { priority: { $gt: queue.priority } },
        { 
          priority: queue.priority,
          queueNumber: { $lt: queue.queueNumber }
        }
      ]
    });

    res.json({ position: position + 1 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get waiting time estimate
exports.getWaitingTime = async (req, res) => {
  try {
    const queue = await Queue.findById(req.params.id);
    if (!queue) {
      return res.status(404).json({ message: 'Queue entry not found' });
    }

    const position = await Queue.countDocuments({
      department: queue.department,
      status: 'Waiting',
      $or: [
        { priority: { $gt: queue.priority } },
        { 
          priority: queue.priority,
          queueNumber: { $lt: queue.queueNumber }
        }
      ]
    });

    // Assuming average consultation time is 15 minutes
    const estimatedTime = position * 15;
    res.json({ estimatedTime });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}; 