const Bed = require('../models/Bed');
const Patient = require('../models/Patient');

// Get all beds
exports.getAllBeds = async (req, res) => {
  try {
    const beds = await Bed.find().populate('currentPatient');
    res.json(beds);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get single bed
exports.getBed = async (req, res) => {
  try {
    const bed = await Bed.findById(req.params.id).populate('currentPatient');
    if (!bed) {
      return res.status(404).json({ message: 'Bed not found' });
    }
    res.json(bed);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create new bed
exports.createBed = async (req, res) => {
  try {
    const bed = new Bed(req.body);
    await bed.save();
    res.status(201).json(bed);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update bed
exports.updateBed = async (req, res) => {
  try {
    const bed = await Bed.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!bed) {
      return res.status(404).json({ message: 'Bed not found' });
    }
    res.json(bed);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete bed
exports.deleteBed = async (req, res) => {
  try {
    const bed = await Bed.findById(req.params.id);
    if (!bed) {
      return res.status(404).json({ message: 'Bed not found' });
    }

    if (bed.status === 'Occupied') {
      return res.status(400).json({ message: 'Cannot delete occupied bed' });
    }

    await bed.remove();
    res.json({ message: 'Bed deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get available beds
exports.getAvailableBeds = async (req, res) => {
  try {
    const beds = await Bed.find({ status: 'Available' });
    res.json(beds);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get beds by ward
exports.getBedsByWard = async (req, res) => {
  try {
    const beds = await Bed.find({ ward: req.params.ward }).populate('currentPatient');
    res.json(beds);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update bed status
exports.updateBedStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const bed = await Bed.findById(req.params.id);
    
    if (!bed) {
      return res.status(404).json({ message: 'Bed not found' });
    }

    if (status === 'Maintenance' && bed.status === 'Occupied') {
      return res.status(400).json({ message: 'Cannot put occupied bed under maintenance' });
    }

    bed.status = status;
    await bed.save();
    res.json(bed);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}; 