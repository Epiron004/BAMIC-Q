const Patient = require('../models/Patient');
const Bed = require('../models/Bed');

// Get all patients
exports.getAllPatients = async (req, res) => {
  try {
    const patients = await Patient.find().populate('assignedBed');
    res.json(patients);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get single patient
exports.getPatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id).populate('assignedBed');
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }
    res.json(patient);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create new patient
exports.createPatient = async (req, res) => {
  try {
    const patient = new Patient(req.body);
    await patient.save();
    res.status(201).json(patient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update patient
exports.updatePatient = async (req, res) => {
  try {
    const patient = await Patient.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }
    res.json(patient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete patient
exports.deletePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    // If patient is assigned to a bed, free the bed
    if (patient.assignedBed) {
      await Bed.findByIdAndUpdate(patient.assignedBed, {
        status: 'Available',
        currentPatient: null
      });
    }

    await patient.remove();
    res.json({ message: 'Patient deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Admit patient
exports.admitPatient = async (req, res) => {
  try {
    const { bedId } = req.body;
    const patient = await Patient.findById(req.params.id);
    
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    const bed = await Bed.findById(bedId);
    if (!bed) {
      return res.status(404).json({ message: 'Bed not found' });
    }

    if (bed.status !== 'Available') {
      return res.status(400).json({ message: 'Bed is not available' });
    }

    // Update bed status
    bed.status = 'Occupied';
    bed.currentPatient = patient._id;
    await bed.save();

    // Update patient status
    patient.currentStatus = 'Admitted';
    patient.admissionDate = new Date();
    patient.assignedBed = bed._id;
    await patient.save();

    res.json({ patient, bed });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Discharge patient
exports.dischargePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    if (patient.currentStatus !== 'Admitted') {
      return res.status(400).json({ message: 'Patient is not admitted' });
    }

    // Free the bed
    if (patient.assignedBed) {
      const bed = await Bed.findById(patient.assignedBed);
      bed.status = 'Available';
      bed.currentPatient = null;
      await bed.save();
    }

    // Update patient status
    patient.currentStatus = 'Discharged';
    patient.dischargeDate = new Date();
    patient.assignedBed = null;
    await patient.save();

    res.json(patient);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}; 