const mongoose = require('mongoose');

const queueSchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: true
  },
  department: {
    type: String,
    required: true,
    enum: ['General', 'Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics']
  },
  priority: {
    type: String,
    enum: ['High', 'Medium', 'Low'],
    default: 'Medium'
  },
  status: {
    type: String,
    enum: ['Waiting', 'In Progress', 'Completed', 'Cancelled'],
    default: 'Waiting'
  },
  queueNumber: {
    type: Number,
    required: true
  },
  checkInTime: {
    type: Date,
    default: Date.now
  },
  startTime: Date,
  endTime: Date,
  notes: String
});

module.exports = mongoose.model('Queue', queueSchema); 