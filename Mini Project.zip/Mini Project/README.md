# Hospital Management System API

A comprehensive backend API for a Hospital Management System built with Node.js, Express, and MongoDB.

## Features

- Patient Management
- Bed Management
- OPD Queue Management
- User Authentication and Authorization
- Real-time Updates using Socket.IO
- Role-based Access Control

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file in the root directory with the following variables:
   ```
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/hospital-management
   JWT_SECRET=your_jwt_secret_key
   NODE_ENV=development
   ```
4. Start the server:
   ```bash
   npm start
   ```

## API Endpoints

### Authentication

- `POST /api/admin/login` - Login user
- `POST /api/admin/register` - Register new user (Admin only)

### Patients

- `GET /api/patients` - Get all patients
- `GET /api/patients/:id` - Get single patient
- `POST /api/patients` - Create new patient
- `PUT /api/patients/:id` - Update patient
- `DELETE /api/patients/:id` - Delete patient
- `POST /api/patients/:id/admit` - Admit patient
- `POST /api/patients/:id/discharge` - Discharge patient

### Beds

- `GET /api/beds` - Get all beds
- `GET /api/beds/:id` - Get single bed
- `POST /api/beds` - Create new bed
- `PUT /api/beds/:id` - Update bed
- `DELETE /api/beds/:id` - Delete bed
- `GET /api/beds/available` - Get available beds
- `GET /api/beds/ward/:ward` - Get beds by ward
- `PUT /api/beds/:id/status` - Update bed status

### Queues

- `GET /api/queues` - Get all queues
- `GET /api/queues/department/:department` - Get queues by department
- `POST /api/queues` - Add patient to queue
- `PUT /api/queues/:id/status` - Update queue status
- `DELETE /api/queues/:id` - Remove from queue
- `GET /api/queues/:id/position` - Get current queue position
- `GET /api/queues/:id/waiting-time` - Get waiting time estimate

### Admin

- `GET /api/admin/users` - Get all users
- `GET /api/admin/users/:id` - Get single user
- `PUT /api/admin/users/:id` - Update user
- `DELETE /api/admin/users/:id` - Delete user
- `PUT /api/admin/users/:id/password` - Change password
- `GET /api/admin/stats` - Get system statistics

## Socket.IO Events

### Queue Events
- `join-queue` - Emitted when a patient joins the queue
- `queue-update` - Broadcasted when queue status changes

### Bed Events
- `bed-status` - Emitted when bed status changes
- `bed-update` - Broadcasted when bed status changes

## Security

- JWT-based authentication
- Role-based access control
- Password hashing using bcrypt
- CORS enabled
- Input validation

## Error Handling

The API uses a centralized error handling middleware that returns appropriate HTTP status codes and error messages.

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

This project is licensed under the MIT License. 